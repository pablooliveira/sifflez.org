/** 
 * Provides functions for reading 
 * a pgm image from a file into an array 
 * and writing it back.
 *
 * ( Does not honour the pgm standard for reading, 
 * but is GIMP compatible which is enough for us...)
 * 
 */

#ifndef __PGM_H
#define __PGM_H 
typedef struct 
{
  unsigned char *img;
  int w,h;
  int colors;
} image;

char * malloc_image(int w, int h);
image * read_pgm(char * file);
void write_pgm(char * file, image * img);
image * create_image(int w, int h, int colors);
#endif
